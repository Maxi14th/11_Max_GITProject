﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float Speed = 5f;
    public float JumpHeight;
    public Rigidbody2D rb2d;
    float HorizontalMove;
    public bool Ground = true;
    public bool canJump;

    public Animator Anim;

    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        HorizontalMove = Input.GetAxis("Horizontal") * Speed;
        transform.position += new Vector3(HorizontalMove, 0, 0) * Time.deltaTime;
        Anim.SetFloat("Movement", Mathf.Abs(HorizontalMove));

        if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            gameObject.transform.eulerAngles = new Vector3(0, 180, 0);   //Turn left
        }

        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            gameObject.transform.eulerAngles = new Vector3(0, 0, 0);    //Turn right
        }


        if(Input.GetKey(KeyCode.Space)&& Ground == true) 
        {
            JumpHeight += 0.1f;
            Speed = 0f;    //correct
        }

        if(JumpHeight >= 10f && Ground == true && canJump == true)
        {
            float tempx = HorizontalMove * Speed;
            float tempy = JumpHeight;

            Ground = false;
            Anim.SetBool("Jump", true);
            rb2d.velocity = new Vector2(tempx, tempy);       
            Invoke("ResetJump", 0.2f);                     //Calling reset jump after 2 seconds
        }

        if(Input.GetKeyUp(KeyCode.Space))
        {
            if(Ground == true)
            {
                Anim.SetBool("Jump", true);
                rb2d.velocity = new Vector2(HorizontalMove * Speed, JumpHeight);
                JumpHeight = 0f;
                
            }
            Speed = 5;
            canJump = false;                                                //correct
        }

        
    }

    public void ResetJump()
    {
        canJump = false;
        JumpHeight = 0f;
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.tag == "Ground")
        {
            Anim.SetBool("Jump", false);
            Ground = true;
            canJump = true;
        }
    } 
}
