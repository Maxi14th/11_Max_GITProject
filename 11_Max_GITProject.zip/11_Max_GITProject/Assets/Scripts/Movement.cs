﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float Speed = 5f;
    public float JumpHeight;
    public Rigidbody2D rb2d;
    float HorizontalMove;
    public bool Ground = true;
    public bool canJump;

    


    public Animator Anim;

    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        HorizontalMove = Input.GetAxis("Horizontal") * Speed;
        transform.position += new Vector3(HorizontalMove, 0, 0) * Time.deltaTime;
        Anim.SetFloat("Movement", Mathf.Abs(HorizontalMove));


        float XLock = Mathf.Clamp(transform.position.x, -8.4f, 8.4f);
        transform.position = new Vector3(XLock, transform.position.y, transform.position.z);


        if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            gameObject.transform.eulerAngles = new Vector3(0, 180, 0);   //Turn left
        }

        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            gameObject.transform.eulerAngles = new Vector3(0, 0, 0);    //Turn right
        }


        if(Input.GetKey(KeyCode.Space)&& Ground == true) 
        {
            JumpHeight += 0.1f;
            Speed = 0f;    //correct
        }

        if(JumpHeight >= 10f && Ground == true && canJump == true)
        {
            Speed = 5;
            canJump = false;
            Ground = false;
            Anim.SetBool("Jump", true);
            rb2d.velocity = new Vector2(HorizontalMove * Speed, JumpHeight);
            Invoke("ResetJump", 0);                     //Calling reset jump after 2 seconds
        }

        if(Input.GetKeyUp(KeyCode.Space) && canJump == true)
        {
            if(Ground == true)
            {
                Anim.SetBool("Jump", true);
                rb2d.velocity = new Vector2(HorizontalMove * Speed, JumpHeight);
                JumpHeight = 0f;

                Speed = 5;
                canJump = false;
                Ground = false;

            }                                                     //correct
        }

        
    }

    public void ResetJump()
    {
        canJump = false;
        JumpHeight = 0f;
    }



    public void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.tag == "Ground")
        {
            Anim.SetBool("Jump", false);
            Ground = true;
            canJump = true;
        }
    } 
}
