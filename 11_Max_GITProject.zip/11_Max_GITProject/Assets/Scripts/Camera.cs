﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    public GameObject Player;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Player.transform.position.y < 4.75f)
        {
            transform.position = new Vector3(transform.position.x, 0f, transform.position.z);
        }

        if (Player.transform.position.y > 4.75f && Player.transform.position.y < 15f)
        {
            transform.position = new Vector3(transform.position.x, 10f, transform.position.z);
        }

        if (Player.transform.position.y > 15f && Player.transform.position.y < 25f)
        {
            transform.position = new Vector3(transform.position.x, 20f, transform.position.z);
        }

        if (Player.transform.position.y > 25f && Player.transform.position.y < 35f)
        {
            transform.position = new Vector3(transform.position.x, 30f, transform.position.z);
        }

        if (Player.transform.position.y > 35f && Player.transform.position.y < 45f)
        {
            transform.position = new Vector3(transform.position.x, 40f, transform.position.z);
        }

        if (Player.transform.position.y > 45f && Player.transform.position.y < 55f)
        {
            transform.position = new Vector3(transform.position.x, 50f, transform.position.z);
        }
    }
}
