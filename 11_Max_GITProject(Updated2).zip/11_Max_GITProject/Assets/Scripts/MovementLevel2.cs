﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementLevel2 : MonoBehaviour
{
    public float Speed = 5f;
    public float JumpHeight = 7f;
    float HorizontalMove;
    private Rigidbody2D rb2d;


    public Animator Anim;
    float JumpCount = 1;
    // Start is called before the first frame update
    void Start()
    {
        rb2d = transform.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        HorizontalMove = Input.GetAxis("Horizontal") * Speed;
        transform.position += new Vector3(HorizontalMove, 0, 0) * Time.deltaTime;
        Anim.SetFloat("Movement", Mathf.Abs(HorizontalMove));


        float XLock = Mathf.Clamp(transform.position.x, -8.5f, 25f);
        transform.position = new Vector3(XLock, transform.position.y, transform.position.z);


        if (Input.GetKeyDown(KeyCode.LeftArrow) || (Input.GetKeyDown(KeyCode.A)))
        {
            gameObject.transform.eulerAngles = new Vector3(0, 180, 0);
        }

        if (Input.GetKeyDown(KeyCode.RightArrow) || (Input.GetKeyDown(KeyCode.D)))
        {
            gameObject.transform.eulerAngles = new Vector3(0, 0, 0);
        }

        if (Input.GetKeyDown(KeyCode.Space) && JumpCount > 0)
        {
            Anim.SetBool("Jump", true);
            rb2d.velocity = Vector3.up * JumpHeight;
            JumpCount -= 1;
        }

        if (Input.GetKeyUp(KeyCode.LeftArrow) || (Input.GetKeyDown(KeyCode.A)))
        {
            transform.position += new Vector3(0, 0, 0) * Time.deltaTime;
        }

        if (Input.GetKeyUp(KeyCode.RightArrow) || (Input.GetKeyDown(KeyCode.D)))
        {
            transform.position += new Vector3(0, 0, 0) * Time.deltaTime;
        }





    }


    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Ground")
        {
            JumpCount = 1;
            Anim.SetBool("Jump", false);
        }
    }

}
